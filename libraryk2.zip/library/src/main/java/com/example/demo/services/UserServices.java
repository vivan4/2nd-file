package com.example.demo.services;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.DAO.UserDAO;
import com.example.demo.model.User;

@Service

public class UserServices {
	@Autowired
	UserDAO dao;

	public ArrayList<User> getMessage() {
		// TODO Auto-generated method stub
		return dao.displayuser();
	}

}
