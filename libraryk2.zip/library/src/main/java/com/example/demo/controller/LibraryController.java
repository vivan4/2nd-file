package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.example.demo.services.LibraryService;

@Controller
@ResponseBody
public class LibraryController {
	
	@Autowired
	LibraryService service;
	@RequestMapping("hello")
	public String getMessage()
	{
		return "Hello World";
	}
	@RequestMapping("user")
	public String getUser() {
		
		return("once completed");
		}
	
}
