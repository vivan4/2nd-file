package com.deloitte.library.main;

import java.util.*;

import com.deloitte.library.model.library;
import com.deloitte.library.services.Libraryimpl;


public class DemoLibrary {
	
	public static void main(String args[]) {
		
		
		Libraryimpl obj=new Libraryimpl();	
		
		Scanner sc = new Scanner(System.in);
		
		int m = 1;
		int y = 0;
		
		ArrayList<library> list = new ArrayList<library>();
		
		while(true) {
			
			System.out.println("Enter 1 to add new books");
			System.out.println("Enter 2 to display books");
			System.out.println("Enter 3 to exit books");
			
			y = sc.nextInt();
			
			switch(y) {
			case 1 :
			{
			
			
		
				System.out.println("Enter the book Name");
				String bookName= sc.next();
				System.out.println("Enter the price");
				int price = sc.nextInt();
				System.out.println("Enter Author Name");
				String author=sc.next();
				
				
				list.add(obj.addBooks(bookName, price, author));
				
				break;
			}
			
			case 2:
			{
				
				for(library li : list) {
					System.out.println(li);
				}
				
				
			}
			
			case 3:
			{
				
				System.exit(0);
			}
			
		}
		}
	}

}
