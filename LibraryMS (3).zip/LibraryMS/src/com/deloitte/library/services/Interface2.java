package com.deloitte.library.services;

import com.deloitte.library.model.library;

public interface Interface2 {
	
	public library addBooks( String bookName, int price, String author);

}
