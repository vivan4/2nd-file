package com.deloitte.library.dao;

import java.sql.*;

import com.deloitte.library.model.library;
public class BooksDAO {

			@SuppressWarnings("null")
			public static Connection connectToDB() throws SQLException{
				
				Connection connection=null;
				try {
					Class.forName("oracle.jdbc.driver.OracleDriver");
					connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","admin");
					return connection;
					
				} catch (ClassNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					connection.close();
				}
				return null;
			}
	


			public static void addBooks(library li) {
				
				try {
					Connection con = connectToDB();
					PreparedStatement stmt=con.prepareStatement("");
					
				}
					
	
	
	
}
}
