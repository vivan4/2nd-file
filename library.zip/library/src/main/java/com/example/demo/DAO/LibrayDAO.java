package com.example.demo.DAO;


import org.springframework.stereotype.Repository;


@Repository
public class LibrayDAO {
	public String getMessage(){
		
		return("Hello world from DAO");
		
	}
	

}
