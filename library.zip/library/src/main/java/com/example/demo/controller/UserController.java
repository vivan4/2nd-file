package com.example.demo.controller;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.example.demo.model.User;
import com.example.demo.services.UserServices;

@Controller
@ResponseBody
public class UserController {
	
		@Autowired
		UserServices service;
		@RequestMapping("/")
		public ArrayList<User> getMessage()
		{
			return service.getMessage();
		}

}
