package com.example.demo.DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import org.springframework.stereotype.Repository;

import com.example.demo.model.User;

@Repository
public class UserDAO {
	public static Connection connectToDB() {
		Connection connection = null;
		try {
			// Step 1 Register to driver
			Class.forName("oracle.jdbc.driver.OracleDriver");
			// Step 2 Create Connection
			connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "system", "admin");
			return connection;
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
	}
	
	public ArrayList<User> displayuser() {
		Connection connection = connectToDB();
		ArrayList<User> userArray = new ArrayList<User>();
		
		try {
			PreparedStatement stmt = connectToDB().prepareStatement("select * from user_tbl");
			ResultSet rs = stmt.executeQuery();
			while(rs.next()) {
				User user = new User();
				user.setUserId(rs.getInt(1));
				user.setName(rs.getString(2));
				user.setEmail(rs.getString(3));
				user.setPhNo(rs.getString(4));
				user.setUserName(rs.getString(5));
				user.setPass(rs.getString(6));
				userArray.add(user);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return userArray;
	}
}
