package com.nexwave;

public interface Interface2 {
	
	public library addBooks( String bookName, int price, String author);

}
