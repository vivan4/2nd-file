package com.nexwave;

public class Libraryimpl implements Interface2 {

	@Override
	public library addBooks(String bookName, int price, String author) {
		// TODO Auto-generated method stub
		
		library li=new library();
		
		
		li.setBookid(library.getCount());
		li.setBookName(bookName);
		li.setPrice(price);
		li.setAuthor(author);
	
		
		
		
		return li;
	}
	
	

}
