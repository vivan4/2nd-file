package com.nexwave;

public interface Interface1 {

	public Classroom addRooms(String Classid, String name, int system, boolean projector, boolean ac,
			boolean availablity, String faculty);

	public Classroom searchRooms(int roomId);

	public void allocateRoom(int system);

	public Classroom[] displayAllClassroom();

	public boolean validate(String username, String password);

}
