package com.nexwave;

public class CommonUtilities {

	public static boolean roomValidation(String Classid) {
		// TODO Auto-generated method stub
		String pattern = "^[0-9]+$";

		if (Classid.matches(pattern)) {
			return true;

		} else
			System.out.println("Enter Valid Id ");
		return false;
	}

}
